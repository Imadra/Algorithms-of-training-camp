#include<iostream>
#include<cstdio>
#include<algorithm>
#include<time.h>
#include<cstring>
#include<ctime>
#include<cmath>
#include<set>
#include<vector>
#include<string>
#define inf 1000*1000*1000
#define f first
#define s second
using namespace std ;
long long n, c[200009], p[200009], d[200009][3];
vector<long long> g[200009];
int go(int v, int color)
{
    if(color==1)
    {
        int ma=c[v];
        for(int i=0;i<g[v].size();i++)
        {
            int to=g[v][i], x;
            if(d[to][2])
                x=d[to][2];
            else
                x=go(to, 2);
            if(x>ma)
                ma=x;
        }
        d[v][color]=ma;
        return ma;
    }
    else
    {
        int mi=inf;
        for(int i=0;i<g[v].size();i++)
        {
            int to=g[v][i], x;
            if(d[to][1])
                x=d[to][1];
            else
                x=go(to, 1);
            if(x<mi)
                mi=x;
        }
        if(mi==inf)
        {
            d[v][color]=c[v];
            return c[v];
        }
        else
        {
            d[v][color]=mi;
            return mi;
        }
    }
}
int main()
{
    freopen("in","r",stdin);
    freopen("out","w",stdout);
    cin>>n;
    for(int i=1;i<=n;i++)
    {
        cin>>p[i]>>c[i];
        g[p[i]].push_back(i);
    }
    cout<<go(1, 1);
}
/*
8
0 4
5 3
1 2
5 1
1 5
4 8
3 6
3 7
*/
