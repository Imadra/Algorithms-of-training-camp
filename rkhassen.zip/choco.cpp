#include<iostream>
#include<cstdio>
#include<algorithm>
#include<time.h>
#include<cstring>
#include<ctime>
#include<cmath>
#include<set>
#include<vector>
#include<string>
#define inf 1000*1000*1000
#define f first
#define s second
using namespace std;

int n,m,s;
int gr[1009][1009];

int f(int n,int m)
{
	int ans[1000];
	if(gr[n][m] >= 0)
		return gr[n][m];
	if(n == 1 && m <= s || m == 1 && n <= s)
    {
		gr[n][m] = 0;
        gr[m][n]=0;
        return 0;
    }
	memset(ans,0,sizeof(ans));
	for(int i = 1; i < n; i++)
		ans[f(i,m) ^ f(n - i,m)] = 1;
	for(int j = 1; j < m; j++)
		ans[f(n,j) ^ f(n,m - j)] = 1;
	while(ans[gr[n][m]])
		gr[n][m]++;
	return gr[n][m];
}
int main()
{
    freopen("in","r",stdin);
    freopen("out","w",stdout);
	cin>>n>>m>>s;
	memset(gr,-1,sizeof(gr));
	if(f(n, m) == 1)
		cout<<1;
	else
		cout<<2;
}
